import { Outlet } from "react-router-dom"

function SignUpLayout() {
    return (
        <>
            <Outlet />
        </>
    )
}

export default SignUpLayout