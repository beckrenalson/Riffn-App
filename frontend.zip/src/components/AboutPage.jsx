function AboutPage() {
    return (
        <>
            <h1>About Riffn</h1>
        </>
    )
}

export default AboutPage